package com.test5.myapplication.data.model

class SingleUser(val user: User)