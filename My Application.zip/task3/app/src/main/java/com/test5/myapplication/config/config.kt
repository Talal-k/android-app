package com.test5.myapplication.config

const val Base_URL = "https://reqres.in/api/"