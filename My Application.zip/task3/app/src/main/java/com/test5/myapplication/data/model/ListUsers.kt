package com.test5.myapplication.data.model

class ListUsers (
    val users: List<User>
        )