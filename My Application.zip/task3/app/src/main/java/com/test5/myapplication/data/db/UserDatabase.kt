package com.test5.myapplication.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.test5.myapplication.data.model.User
@Database(entities = [User::class], version = 1)
abstract class UserDatabase:RoomDatabase() {
    abstract fun UserDao():UserDao

    companion object{
        @Volatile private var instance: UserDatabase? = null

        fun getDatabase(context:Context) : UserDatabase {
            val tempInstance = instance
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val temp = buildDatabase(context)
                instance = temp
                return temp
            }
        }
    private fun buildDatabase(context: Context):UserDatabase {
        return Room.databaseBuilder(context, UserDatabase::class.java, "Users")
            .fallbackToDestructiveMigration()
            .build()
    }
        }
}