package com.test5.myapplication.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "User")
data class User (
    @SerializedName("id")
    @PrimaryKey
    val id: Int,
    @SerializedName("email")
    val email: String?,
    @SerializedName("firstname")
    val firstName: String?,
    @SerializedName("lastname")
    val lastName: String?,
    @SerializedName("avatar")
    val Image: String?
)